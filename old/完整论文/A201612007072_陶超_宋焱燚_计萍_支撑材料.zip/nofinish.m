
x0
y0
z0
h = abs(z0)

H = 18;%ˮ��
v1 = 36;%����
v2 = 1.5;%ˮ��
beta = pi/2;
rho = 1.025*10^3;
g = 9.8;


%������������
m0 = 1000;
H0 = 2;
D0 = 2;
F0 = rho*g*pi*(D0/2)^2*h;
G0=m0*g;
Fw = 0.625*(D0*(H0 - h))*v1^2;
Fs = 374*(D0*h)*v2^2;

T1x = T1*cos(theta1)*sin(alpha1);
T1y = T1*cos(theta1)*cos(alpha1);
T1z = T1*sin(theta1);


X0 = []
[x, fv] = fsolve(@D3fun)
























