function y = D3fun(x)

beta = pi/2;
m0 = 1000;
H0 = 2;
D0 = 2;
F0 = rho*g*pi*(D0/2)^2*h;
G0=m0*g;
Fw = 0.625*(D0*(H0 - h))*v1^2;
Fs = 374*(D0*h)*v2^2;

T1 = x(1);
theta1 = x(2);
alpha1 = x(3);

T1x = T1*cos(theta1)*sin(alpha1);
T1y = T1*cos(theta1)*cos(alpha1);
T1z = T1*sin(theta1);

y = [T1x - Fw - Fs*cos(beta);...
    T1y - Fs*sin(beta);...
    T1z + G0 - F0];













